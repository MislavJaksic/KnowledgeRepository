package hr.inceptum.bigdata.kafka;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.hadoop.util.hash.Hash;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.rdd.RDD;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.dstream.InputDStream;
import org.apache.spark.streaming.kafka010.CanCommitOffsets;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import redis.clients.jedis.Jedis;
import scala.Function1;
import scala.Tuple2;
import scala.reflect.ClassTag;
import scala.runtime.BoxedUnit;

import javax.swing.text.DateFormatter;
import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

public class Reader {

    private static final Gson gson = new GsonBuilder().create();
    public static final Type type = new TypeToken<Map<String, String>>() {
    }.getType();

    private final static Logger LOGGER = Logger.getLogger(Reader.class.getName());


    private static Map<String, Object> getKafkaParams() {
        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("bootstrap.servers", "192.168.50.56:9094");
        kafkaParams.put("key.deserializer", StringDeserializer.class);
        kafkaParams.put("value.deserializer", StringDeserializer.class);
        kafkaParams.put("group.id", "spark-processor-service");
        kafkaParams.put("auto.offset.reset", "latest");
        kafkaParams.put("enable.auto.commit", true);
        return Collections.unmodifiableMap(kafkaParams);
    }

    public static JavaInputDStream<ConsumerRecord<String, String>> createDirectStream(JavaStreamingContext ssc, String topic) {
        Map<String, Object> kafkaParams = getKafkaParams();
        Collection<String> topics = Collections.singletonList(topic);
        return KafkaUtils.createDirectStream(
                ssc,
                LocationStrategies.PreferConsistent(),
                ConsumerStrategies.Subscribe(topics, kafkaParams)

        );
    }

    private static void test() {
        String s = "\"{\\\"eventname\\\": \\\"SERVICE ALERT\\\", \\\"host_name\\\": \\\"c-pro-mimato-zg02-psndta\\\", \\\"ipadresa\\\": \\\"10.70.17.11\\\", \\\"vendor\\\": \\\"Patton\\\", \\\"productnumber\\\": \\\"SN-DTA/2BIS4V\\\", \\\"cisid\\\": \\\"204590\\\", \\\"silocationid\\\": \\\"190998\\\", \\\"tipid\\\": \\\"1\\\", \\\"state\\\": \\\"SOFT\\\", \\\"status_code\\\": \\\"WARNING\\\", \\\"info\\\": \\\"PING WARNING - DUPLICATES FOUND! Packet loss = 0%, RTA = 3.69 ms\\\", \\\"time\\\": \\\"2018/06/15 00:52:21\\\"}\"";

        s = StringEscapeUtils.unescapeJava(s);
        System.out.println(s);
        s = s.substring(1, s.length() - 1);

        System.out.println(s);

        HashMap<String, String> values = new HashMap<String, String>(gson.fromJson(s, type));


        String dateStr = values.get("time");
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        Date date;
        try {
            date = format.parse(dateStr);
        } catch (ParseException e) {
            System.out.println(e.toString());
            return;
        }
        long epoch = date.getTime();
        String key = String.format("%s:%s:%s:%d", "cpu", "alerts", values.get("ipadresa"), epoch);
        HashMap<String, String> valuesToSave = new HashMap<String, String>();
        valuesToSave.put("hostname", values.get("host_name"));
        valuesToSave.put("status", values.get("status_code"));
        valuesToSave.put("state", values.get("state"));
        valuesToSave.put("info", values.get("info"));
        String value = gson.toJson(valuesToSave);
        System.out.printf("Key: %s, Value: %s, Status: %s\n", key, value, "OK");
    }

    public static void main(String[] args) {


        SparkConf conf = new SparkConf()
                .setAppName("exampleKafkaReader")
                .setMaster("local[2]");
        JavaStreamingContext ssc = new JavaStreamingContext(conf, new Duration(1000));

        JavaInputDStream<ConsumerRecord<String, String>> stream = Reader.createDirectStream(ssc, "alarms-service-raw");

        stream
                .map(ConsumerRecord::value)
                .map(s -> new HashMap<String, String>(gson.fromJson(s, type)))
                .filter(json -> {
                    String info = json.get("info");
                    return info.toLowerCase().contains("cpu");
                })
                .mapPartitions(hashMapIterator -> {
                    Jedis r = new Jedis("192.168.50.56");
                    List<Tuple2<String, String>> keyValues = new ArrayList<>();
                    for (; hashMapIterator.hasNext(); ) {
                        HashMap<String, String> values = hashMapIterator.next();
                        String dateStr = values.get("time");
                        DateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
                        Date date;
                        try {
                            date = format.parse(dateStr);
                        } catch (ParseException e) {
                            System.out.println(e.toString());
                            continue;
                        }
                        long epoch = date.getTime();

                        String key = String.format("%s:%s:%s:%d", "cpu", "alerts", values.get("ipadresa"), epoch);

                        HashMap<String, String> valuesToSave = new HashMap<>();
                        valuesToSave.put("hostname", values.get("host_name"));
                        valuesToSave.put("status", values.get("status_code"));
                        valuesToSave.put("state", values.get("state"));
                        valuesToSave.put("info", values.get("info"));

                        String value = gson.toJson(valuesToSave);

                        String status = r.set(key, value);
                        System.out.printf("Key: %s, Value: %s, Status: %s\n", key, value, status);
                        keyValues.add(new Tuple2<>(key, value));
                    }
                    r.close();
                    return keyValues.iterator();
                })
                .print();

        ssc.start();
        try {
            ssc.awaitTermination();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("passed");

    }
}
